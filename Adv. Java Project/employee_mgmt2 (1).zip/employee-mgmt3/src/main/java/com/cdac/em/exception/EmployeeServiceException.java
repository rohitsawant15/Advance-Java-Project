package com.cdac.em.exception;

public class EmployeeServiceException extends RuntimeException{
	public EmployeeServiceException(String msg1) {
		super(msg1);
	}
}
